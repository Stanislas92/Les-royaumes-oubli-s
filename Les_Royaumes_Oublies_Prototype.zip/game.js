const config = {
    type: Phaser.AUTO,
    width: 1280,
    height: 720,
    backgroundColor: '#4f8f3c',
    scene: {
        create,
        update
    }
};

let wood = 0;
let gold = 100;
let text;

new Phaser.Game(config);

function create() {
    this.add.text(30, 20, '🏰 Les Royaumes Oubliés', { fontSize: '32px', color: '#ffffff' });

    const castle = this.add.rectangle(640, 300, 220, 180, 0x999999);
    this.add.text(580, 285, 'CHÂTEAU', { fontSize: '28px', color: '#000' });

    const tree = this.add.circle(250, 500, 45, 0x2e8b57);
    this.add.text(210, 565, 'Forêt', { fontSize: '24px', color: '#fff' });

    tree.setInteractive();
    tree.on('pointerdown', () => {
        wood += 10;
        updateUI();
    });

    castle.setInteractive();
    castle.on('pointerdown', () => {
        if (wood >= 50) {
            wood -= 50;
            gold += 50;
            updateUI();
        }
    });

    text = this.add.text(30, 90, '', {
        fontSize: '26px',
        color: '#ffffff'
    });

    updateUI();
}

function updateUI() {
    text.setText(
        '🌳 Bois : ' + wood +
        '\n🪙 Or : ' + gold +
        '\n\nClique sur la forêt pour récolter du bois.' +
        '\nClique sur le château pour l’améliorer.'
    );
}

function update() {}
